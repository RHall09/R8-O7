var classStatTracker =
[
    [ "StatTracker", "classStatTracker.html#a8966aabbd4a2eaddd975fcfc137c2a07", null ],
    [ "add_data", "classStatTracker.html#aed7b88d1ddaa6a6f5dda2505f29dc56f", null ],
    [ "add_data", "classStatTracker.html#aa92e8ed87f976ab252cea668e03aa190", null ],
    [ "add_data", "classStatTracker.html#adf0fd05d23fb13ed4fbd7857cfc4c33a", null ],
    [ "average", "classStatTracker.html#a8c0d201e498e31cbdf42e21cac5200e8", null ],
    [ "clear", "classStatTracker.html#a39f4777ec147f38013110a419d1287db", null ],
    [ "num_points", "classStatTracker.html#a9c58a53a361938e03690c6908d2399e7", null ],
    [ "std_dev", "classStatTracker.html#a3418a2c1e71561b48b40badc59d6500b", null ],
    [ "avg", "classStatTracker.html#a901ab54486e684db2475f5dad511e47d", null ],
    [ "n_pts", "classStatTracker.html#a81372e9e81401c248fc779d8567be82a", null ],
    [ "new_points", "classStatTracker.html#a1f08225030e78ea264f6f000220b7003", null ],
    [ "sdev", "classStatTracker.html#a86f93baaefeaf10714829e95457fc2aa", null ],
    [ "sqrd_sum", "classStatTracker.html#a744f25ce38ccb7eeb50372537f66ff37", null ],
    [ "sum", "classStatTracker.html#aa392efff616ccca488125fbfe37c0c59", null ]
];