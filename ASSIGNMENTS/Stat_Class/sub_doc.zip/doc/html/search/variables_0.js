var searchData=
[
  ['avg_26',['avg',['../classStatTracker.html#a901ab54486e684db2475f5dad511e47d',1,'StatTracker']]]
];
