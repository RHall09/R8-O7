var searchData=
[
  ['num_5fpoints_23',['num_points',['../classStatTracker.html#a9c58a53a361938e03690c6908d2399e7',1,'StatTracker']]]
];
