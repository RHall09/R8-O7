var searchData=
[
  ['sdev_9',['sdev',['../classStatTracker.html#a86f93baaefeaf10714829e95457fc2aa',1,'StatTracker']]],
  ['sqrd_5fsum_10',['sqrd_sum',['../classStatTracker.html#a744f25ce38ccb7eeb50372537f66ff37',1,'StatTracker']]],
  ['stat_5ftracker_2ecpp_11',['stat_tracker.cpp',['../stat__tracker_8cpp.html',1,'']]],
  ['stat_5ftracker_2eh_12',['stat_tracker.h',['../stat__tracker_8h.html',1,'']]],
  ['stattracker_13',['StatTracker',['../classStatTracker.html',1,'StatTracker'],['../classStatTracker.html#a8966aabbd4a2eaddd975fcfc137c2a07',1,'StatTracker::StatTracker()']]],
  ['std_5fdev_14',['std_dev',['../classStatTracker.html#a3418a2c1e71561b48b40badc59d6500b',1,'StatTracker']]],
  ['sum_15',['sum',['../classStatTracker.html#aa392efff616ccca488125fbfe37c0c59',1,'StatTracker']]]
];
