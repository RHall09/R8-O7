var searchData=
[
  ['stattracker_24',['StatTracker',['../classStatTracker.html#a8966aabbd4a2eaddd975fcfc137c2a07',1,'StatTracker']]],
  ['std_5fdev_25',['std_dev',['../classStatTracker.html#a3418a2c1e71561b48b40badc59d6500b',1,'StatTracker']]]
];
