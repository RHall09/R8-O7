var searchData=
[
  ['add_5fdata_0',['add_data',['../classStatTracker.html#aed7b88d1ddaa6a6f5dda2505f29dc56f',1,'StatTracker::add_data(float new_pt)'],['../classStatTracker.html#aa92e8ed87f976ab252cea668e03aa190',1,'StatTracker::add_data(int32_t new_pt)'],['../classStatTracker.html#adf0fd05d23fb13ed4fbd7857cfc4c33a',1,'StatTracker::add_data(uint32_t new_pt)']]],
  ['average_1',['average',['../classStatTracker.html#a8c0d201e498e31cbdf42e21cac5200e8',1,'StatTracker']]],
  ['avg_2',['avg',['../classStatTracker.html#a901ab54486e684db2475f5dad511e47d',1,'StatTracker']]]
];
