var searchData=
[
  ['sdev_30',['sdev',['../classStatTracker.html#a86f93baaefeaf10714829e95457fc2aa',1,'StatTracker']]],
  ['sqrd_5fsum_31',['sqrd_sum',['../classStatTracker.html#a744f25ce38ccb7eeb50372537f66ff37',1,'StatTracker']]],
  ['sum_32',['sum',['../classStatTracker.html#aa392efff616ccca488125fbfe37c0c59',1,'StatTracker']]]
];
