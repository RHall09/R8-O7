var searchData=
[
  ['n_5fpts_27',['n_pts',['../classStatTracker.html#a81372e9e81401c248fc779d8567be82a',1,'StatTracker']]],
  ['new_5fpoints_28',['new_points',['../classStatTracker.html#a1f08225030e78ea264f6f000220b7003',1,'StatTracker']]]
];
